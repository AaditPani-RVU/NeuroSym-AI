__all__ = ["llm", "rules", "engine", "utils"]
__version__ = "0.1.0"
from dotenv import load_dotenv
load_dotenv()  # will look for .env in repo root
